#include "Graph.h"

void printGraph(Graph &g)
{
    for (int i = 0; i < g.V; ++i)
    {
        cout << "Vertex " << g.vertices[i].vertex << " is linked with ";
        printEdges(g.vertices[i].edges);
        cout << endl;
    }
}

void printEdges(Edge *edges)
{
    Edge *temp = edges;
    while (temp != nullptr)
    {
        cout << "Vertex " << temp->dest;
        if (temp->next != nullptr)
        {
            cout << ", ";
        }
        temp = temp->next;
    }
}