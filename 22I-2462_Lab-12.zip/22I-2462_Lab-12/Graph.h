#include "Vertex.h"
const int MAX_VERTICES = 100;

class Graph
{
public:
    int V;
    Vertex vertices[MAX_VERTICES];

public:
    Graph(int V) : V(V)
    {
        for (int i = 0; i < V; ++i)
        {
            vertices[i].vertex = i;
            vertices[i].edges = nullptr;
        }
    }

    virtual void addEdge(int src, int dest, float weight = 1.0)
    {
        Edge *newEdge = new Edge{dest, weight, nullptr};
        vertices[src].edges = addEdgeToList(vertices[src].edges, newEdge);
    }

    Edge *addEdgeToList(Edge *head, Edge *newEdge)
    {
        newEdge->next = head;
        return newEdge;
    }
};