#include "Graph.h"

class WeightedGraph : public Graph
{
public:
    using Graph::Graph;

    void addEdge(int src, int dest, float weight) override
    {
        Graph::addEdge(src, dest, weight);
    }
};