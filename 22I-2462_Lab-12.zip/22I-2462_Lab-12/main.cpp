#include "Menu.h"

int main()
{
    displayMenu();
    return 0;
}