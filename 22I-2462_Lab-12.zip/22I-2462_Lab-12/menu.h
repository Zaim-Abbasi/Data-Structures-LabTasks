#include "Graph.h"
#include "Undirected_Graph.h"
#include "Weighted_Graph.h"
#include "Print_Graph.h"

void displayMenu()
{
    int V = 5;
    Graph g(V);
    int src, dest;
    float weight;
    bool undirected;
    int choice;

    while (true)
    {
        cout << "1. Add edge\n2. Print graph\n3. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter source, destination, weight, undirected (0/1): ";
            cin >> src >> dest >> weight >> undirected;
            // g.addEdge(src, dest, weight, undirected);
            break;
        case 2:
            printGraph(g);
            break;
        case 3:
            return;
        default:
            cout << "Invalid choice\n";
        }
    }
}