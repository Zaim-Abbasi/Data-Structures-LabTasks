#include "Graph.h"

class UndirectedGraph : public Graph
{
public:
    using Graph::Graph;

    void addEdge(int src, int dest, float weight = 1.0) override
    {
        Graph::addEdge(src, dest, weight);
        Edge *newEdgeUndirected = new Edge{src, weight, nullptr};
        vertices[dest].edges = addEdgeToList(vertices[dest].edges, newEdgeUndirected);
    }
};