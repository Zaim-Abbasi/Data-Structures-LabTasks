#include "Edge.h"
class Vertex
{
public:
    int vertex;
    Edge *edges;
};