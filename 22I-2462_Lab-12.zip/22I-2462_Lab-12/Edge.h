#include <iostream>
using namespace std;
class Edge
{
public:
    int dest;
    float weight;
    Edge *next;
};