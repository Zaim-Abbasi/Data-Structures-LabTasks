#include "road.h"
// interaction: vertices
class Intersection
{
public:
    Road *roads;
    Intersection() : roads(nullptr) {}
};